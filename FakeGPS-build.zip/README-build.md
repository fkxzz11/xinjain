# FakeGPS 构建工程

把 `FakeGPS-src/` 里的重建源码打包成 **`FakeGPS.dylib` / `.deb`** 的完整 Theos 工程。

## 为什么这里没有现成的 .dylib

当前机器是 Windows，已实测：`clang` / `xcrun` / `make` / `ldid` / `dpkg-deb` / `wsl` 全部不存在，也没有 Theos 与 iOS SDK。

编译 iOS arm64 Objective-C dylib 必须有：clang + **iOS SDK**（UIKit/CoreLocation/MapKit 头文件 + 符号）+ 链接 `libsubstrate`。Windows 上无法产出，因此本目录交付的是**可直接出二进制**的工程。

另外本机连"下载工具链"这条路也走不通：PowerShell 的 TLS 出口不可用（`schannel: SEC_E_NO_CREDENTIALS`），`git` 未安装，C 盘剩余空间接近 0，无法拉取 LLVM 与 iOS SDK。

## 没有 Mac 时的最短路径（全程只用浏览器）

1. GitHub 新建一个 **Private** 仓库（例：`fakegps-build`），不要勾选 README/gitignore。
2. 解压 `FakeGPS-build.zip`，把里面的**全部文件**（含 `.github` 目录）拖进网页上传区，Commit。
   * 若网页不显示 `.github` 目录：先在本机把文件夹压缩成 zip 再上传，GitHub 网页支持拖 zip 吗？不支持——请改用「Add file → Create new file」，路径填
     `.github/workflows/build.yml`，把本机该文件内容粘进去即可。
3. 仓库页 → **Actions** → 左侧 `build` → **Run workflow**。
   * 首次会提示启用 Actions，点绿色按钮即可；构建约 3–6 分钟。
4. 构建完成后进那次 run，页面底部 **Artifacts** 下载 `FakeGPS-dylib.zip`。
   里面是 `FakeGPS.dylib`、`FakeGPSPlus.dylib`、`*.deb` 和过滤 plist。
5. 装到手机：
   * 有 Filza：把 `.deb` 传到手机，点开安装；
   * 或把 `FakeGPS.dylib` + `FakeGPS.plist` 放进 `/Library/MobileSubstrate/DynamicLibraries/`，然后 `killall -9 SpringBoard`。

> 不知道目标 App 的 bundle id 时：把 `FakeGPS-anyapp.plist` 改名为 `FakeGPS.plist` 再构建，会注入所有进程（风险见该文件内注释）。

## 方式 A：本机 Theos（macOS 或 Linux）

```bash
# 1. 装 Theos（一次性）
bash -c "$(curl -fsSL https://raw.githubusercontent.com/theos/theos/master/bin/install-theos)"

# 2. 改过滤目标：把 com.example.targetapp 换成《门店地址》页所在 App 的 bundle id
#    可手改 FakeGPS.plist，或用脚本重写：
./build.sh com.example.targetapp

# 3. 产物
packages/com.example.fakegps_1.1.0_iphoneos-arm.deb
.theos/obj/FakeGPS.dylib          # 直接取 dylib 也可
```

只想要 dylib、不打 deb：`make`。

## 方式 B：不装 Mac，用 GitHub Actions

`.github/workflows/build.yml` 会在 `macos-14` 上装 Theos + iOS SDK 并构建，产物作为 artifact `FakeGPS-dylib` 下载（含 `.deb`、`.dylib`、过滤 plist）。

上传本目录到仓库 → Actions → `build` → Run workflow 即可。

## 安装

```bash
# deb 路线
scp packages/*.deb root@device:/tmp/ && ssh root@device 'dpkg -i /tmp/*.deb && killall -9 SpringBoard'

# dylib 路线（原 FakeGPS.dylib 已在设备上时直接覆盖）
scp FakeGPS.dylib root@device:/Library/MobileSubstrate/DynamicLibraries/FakeGPS.dylib
ssh root@device 'killall -9 SpringBoard'
```

Dopamine / palera1n（rootless）需要：

```bash
export THEOS_PACKAGE_SCHEME = rootless
# 并把 control 的 Architecture 改成 iphoneos-arm64
# 安装路径变为 /var/jb/Library/MobileSubstrate/DynamicLibraries/
```

## 只装“新增功能”的独立小 dylib

不想重编原版时，用 `Makefile.plus`：

```bash
make -f Makefile.plus package FINALPACKAGE=1
# → FakeGPSPlus.dylib + FakeGPSPlus.plist
```

`FakeGPSAutoAddress.m` 只做两件事：hook `-[UIViewController viewDidAppear:]`、读写 `NSUserDefaults`，**不引用原 dylib 的任何符号**，可以和原 `FakeGPS.dylib` 并列加载。

## 编译风险（源码是按反编译重建的，未在本机验证过）

| 位置 | 风险 | 处理 |
|---|---|---|
| `MapViewController.m` 里 `kCALayerMinXMinYCorner` 等 | 需 `#import <QuartzCore/QuartzCore.h>` | 已引入 |
| `FakeGPSHooks.m` 的 `#import <substrate.h>` | 需要 `LIBRARIES = substrate` | Makefile 已设 |
| `FGAutoAddressInstall()` 跨文件声明 | 已在 `FakeGPSHooks.m` 里 `extern` | 已处理 |
| ARC 下 `performSelector:withObject:` | 可能报 `-Warc-performSelector-leaks` | 已加 `-Wno-objc-method-access`；必要时再加 `-Wno-arc-performSelector-leaks` |
| `objc_msgSend` 强转调用（`segmentAction:` / `initTapGess`） | 需 `<objc/message.h>` | 已引入 |
| 未使用变量 / 空实现方法 | 只是 warning | 不影响产物 |

首次 `make` 若报某个头文件找不到，按提示补 `#import`，或在 Makefile 的 `FakeGPS_CFLAGS` 里追加 `-Wno-...`。
