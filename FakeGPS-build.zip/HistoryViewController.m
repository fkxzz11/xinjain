//
//  HistoryViewController.m
//  FakeGPS.dylib
//
//  由 IG5 / Ghidra 反编译重建（0x109e0 .. 0x121f8）。
//

#import "HistoryViewController.h"

static NSString *const kLocationHistoryKey = @"LocationHistory";

@implementation HistoryViewController

#pragma mark - 生命周期

- (void)viewDidLoad
{
    [super viewDidLoad];

    self.title = @"位置历史";

    UIBarButtonItem *closeItem =
        [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemClose
                                                      target:self
                                                      action:@selector(closeButtonTapped)];
    self.navigationItem.leftBarButtonItem = closeItem;

    UIBarButtonItem *clearItem =
        [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemTrash
                                                      target:self
                                                      action:@selector(clearAllHistory)];
    self.navigationItem.rightBarButtonItem = clearItem;

    [self.tableView registerClass:[UITableViewCell class] forCellReuseIdentifier:@"HistoryCell"];
    self.tableView.rowHeight = UITableViewAutomaticDimension;
    self.tableView.estimatedRowHeight = 60.0;
}

- (void)closeButtonTapped
{
    [self dismissViewControllerAnimated:YES completion:nil];
}

#pragma mark - UITableViewDataSource

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return self.historyItems.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"HistoryCell"
                                                            forIndexPath:indexPath];
    cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;

    [self configureCell:cell withItem:self.historyItems[indexPath.row]];
    return cell;
}

- (void)configureCell:(UITableViewCell *)cell withItem:(NSDictionary *)item
{
    cell.textLabel.numberOfLines = 0;

    NSString *address = item[@"address"] ?: @"未知位置";
    NSString *note    = item[@"note"] ?: @"";

    if (note.length == 0) {
        cell.textLabel.text = address;
        cell.textLabel.textColor = [UIColor labelColor];
        cell.textLabel.font = [UIFont systemFontOfSize:16.0 weight:UIFontWeightMedium];
        return;
    }

    NSMutableAttributedString *attributed =
        [[NSMutableAttributedString alloc] init];

    NSAttributedString *addressLine =
        [[NSAttributedString alloc] initWithString:address
                                        attributes:@{
            NSFontAttributeName            : [UIFont systemFontOfSize:16.0 weight:UIFontWeightMedium],
            NSForegroundColorAttributeName : [UIColor labelColor],
        }];
    [attributed appendAttributedString:addressLine];

    [attributed appendAttributedString:
        [[NSAttributedString alloc] initWithString:@"\n" attributes:nil]];

    NSString *noteText = [NSString stringWithFormat:@"备注: %@", note];
    NSAttributedString *noteLine =
        [[NSAttributedString alloc] initWithString:noteText
                                        attributes:@{
            NSFontAttributeName            : [UIFont systemFontOfSize:14.0],
            NSForegroundColorAttributeName : [UIColor secondaryLabelColor],
        }];
    [attributed appendAttributedString:noteLine];

    cell.textLabel.attributedText = attributed;
}

#pragma mark - UITableViewDelegate

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];

    if ([self.delegate respondsToSelector:@selector(didSelectHistoryItem:)]) {
        [self.delegate didSelectHistoryItem:self.historyItems[indexPath.row]];
    }

    [self.navigationController dismissViewControllerAnimated:YES completion:nil];
}

- (UISwipeActionsConfiguration *)tableView:(UITableView *)tableView
trailingSwipeActionsConfigurationForRowAtIndexPath:(NSIndexPath *)indexPath
{
    __weak typeof(self) weakSelf = self;

    UIContextualAction *deleteAction =
        [UIContextualAction contextualActionWithStyle:UIContextualActionStyleDestructive
                                                title:@"删除"
                                              handler:^(UIContextualAction *action,
                                                        UIView *sourceView,
                                                        void (^completionHandler)(BOOL)) {
        [weakSelf deleteItemAtIndex:indexPath.row];
        completionHandler(YES);
    }];
    deleteAction.image = [UIImage systemImageNamed:@"trash"];

    UIContextualAction *editAction =
        [UIContextualAction contextualActionWithStyle:UIContextualActionStyleNormal
                                                title:@"备注"
                                              handler:^(UIContextualAction *action,
                                                        UIView *sourceView,
                                                        void (^completionHandler)(BOOL)) {
        weakSelf.editingIndexPath = indexPath;
        [weakSelf showEditNoteAlertForItemAtIndex:indexPath.row];
        completionHandler(YES);
    }];
    editAction.backgroundColor = [UIColor systemBlueColor];
    editAction.image = [UIImage systemImageNamed:@"pencil"];

    return [UISwipeActionsConfiguration configurationWithActions:@[ deleteAction, editAction ]];
}

#pragma mark - 备注

- (void)showEditNoteAlertForItemAtIndex:(NSInteger)index
{
    NSDictionary *item = self.historyItems[index];

    UIAlertController *alert =
        [UIAlertController alertControllerWithTitle:@"编辑备注"
                                            message:nil
                                     preferredStyle:UIAlertControllerStyleAlert];

    [alert addTextFieldWithConfigurationHandler:^(UITextField *textField) {
        textField.placeholder = @"输入备注信息";
        textField.text = item[@"note"] ?: @"";
        textField.clearButtonMode = UITextFieldViewModeAlways;
        textField.returnKeyType = UIReturnKeyDone;
        textField.delegate = self;
    }];

    __weak typeof(self) weakSelf = self;
    [alert addAction:[UIAlertAction actionWithTitle:@"取消"
                                              style:UIAlertActionStyleCancel
                                            handler:nil]];
    [alert addAction:[UIAlertAction actionWithTitle:@"保存"
                                              style:UIAlertActionStyleDefault
                                            handler:^(UIAlertAction *action) {
        NSString *text = alert.textFields.firstObject.text;
        [weakSelf updateNote:text forItemAtIndex:index];
    }]];

    [self presentViewController:alert animated:YES completion:nil];
}

- (void)updateNote:(NSString *)note forItemAtIndex:(NSInteger)index
{
    NSMutableDictionary *item = [self.historyItems[index] mutableCopy];
    item[@"note"] = note;
    self.historyItems[index] = item;

    [self.tableView reloadRowsAtIndexPaths:@[ [NSIndexPath indexPathForRow:index inSection:0] ]
                          withRowAnimation:UITableViewRowAnimationFade];

    [[NSUserDefaults standardUserDefaults] setObject:self.historyItems forKey:kLocationHistoryKey];
}

#pragma mark - 删除

- (void)deleteItemAtIndex:(NSInteger)index
{
    [self.historyItems removeObjectAtIndex:index];
    [self.tableView deleteRowsAtIndexPaths:@[ [NSIndexPath indexPathForRow:index inSection:0] ]
                          withRowAnimation:UITableViewRowAnimationAutomatic];

    [[NSUserDefaults standardUserDefaults] setObject:self.historyItems forKey:kLocationHistoryKey];
}

- (void)clearAllHistory
{
    UIAlertController *alert =
        [UIAlertController alertControllerWithTitle:@"确认清除"
                                            message:@"确定要删除所有历史记录吗？"
                                     preferredStyle:UIAlertControllerStyleAlert];

    [alert addAction:[UIAlertAction actionWithTitle:@"取消"
                                              style:UIAlertActionStyleCancel
                                            handler:nil]];

    __weak typeof(self) weakSelf = self;
    [alert addAction:[UIAlertAction actionWithTitle:@"确定"
                                              style:UIAlertActionStyleDestructive
                                            handler:^(UIAlertAction *action) {
        [weakSelf.historyItems removeAllObjects];
        [weakSelf.tableView reloadData];
        [[NSUserDefaults standardUserDefaults] removeObjectForKey:kLocationHistoryKey];
    }]];

    [self presentViewController:alert animated:YES completion:nil];
}

#pragma mark - UITextFieldDelegate

- (BOOL)textField:(UITextField *)textField
    shouldChangeCharactersInRange:(NSRange)range
                replacementString:(NSString *)string
{
    NSString *candidate = [textField.text stringByReplacingCharactersInRange:range
                                                                 withString:string];
    return (candidate.length < 31);
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
    [textField resignFirstResponder];
    return YES;
}

@end
