//
//  HistoryViewController.h
//  FakeGPS.dylib
//
//  由 IG5 / Ghidra 反编译重建（HistoryViewController @0x1eb90）。
//

#import <UIKit/UIKit.h>

@class HistoryViewController;

@protocol HistorySelectionDelegate <NSObject>
@optional
- (void)didSelectHistoryItem:(NSDictionary *)item;
@end

@interface HistoryViewController : UITableViewController <UITextFieldDelegate>

@property (nonatomic, strong) NSMutableArray<NSDictionary *> *historyItems;
@property (nonatomic, weak)   id<HistorySelectionDelegate>   delegate;
@property (nonatomic, strong) NSIndexPath                    *editingIndexPath;

@end
