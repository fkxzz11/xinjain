//
//  MapViewController.h
//  FakeGPS.dylib
//
//  由 IG5 / Ghidra 反编译重建（类符号 __objc_classlist @0x19060，MapViewController @0x1eb40）。
//

#import <UIKit/UIKit.h>
#import <MapKit/MapKit.h>
#import <CoreLocation/CoreLocation.h>

@class MapViewController;

@protocol MapViewControllerDelegate <NSObject>
@optional
- (void)didSelectHistoryItem:(NSDictionary *)item;
@end

@protocol HistorySelectionDelegate;

@interface MapViewController : UIViewController
<
    UISearchBarDelegate,
    UITableViewDelegate,
    UITableViewDataSource,
    MKMapViewDelegate,
    CLLocationManagerDelegate
>

@property (nonatomic, weak)   id<MapViewControllerDelegate> delegate;

@property (nonatomic, strong) MKMapView            *mapView;
@property (nonatomic, strong) CLLocationManager    *locationManager;
@property (nonatomic, strong) CLGeocoder           *geocoder;
@property (nonatomic, strong) UILongPressGestureRecognizer *longPressRecognizer;
@property (nonatomic, strong) UISearchBar          *searchBar;
@property (nonatomic, strong) UITableView          *suggestionTableView;
@property (nonatomic, strong) NSArray              *addressSuggestions;
@property (nonatomic, strong) NSMutableArray       *locationHistory;
@property (nonatomic, strong) UISegmentedControl   *actionControl;
@property (nonatomic, strong) UIView               *infoCardView;
@property (nonatomic, strong) UILabel              *locationLabel;
@property (nonatomic, strong) UILabel              *altitudeLabel;
@property (nonatomic, strong) UIStackView          *switchStack;
@property (nonatomic, strong) UISwitch             *locationSwitch;
@property (nonatomic, strong) UISwitch             *altitudeSwitch;
@property (nonatomic, strong) UIButton             *confirmButton;
@property (nonatomic, strong) MKUserTrackingButton *trackingButton;
@property (nonatomic, strong) UIButton             *mapTypeButton;

@end
