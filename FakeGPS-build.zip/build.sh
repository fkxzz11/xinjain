#!/usr/bin/env bash
#
# 一行构建 FakeGPS.dylib / .deb
#
#   ./build.sh                       # 用当前 FakeGPS.plist 里的 bundle id
#   ./build.sh com.foo.app com.bar   # 重写过滤 plist 后构建（多目标）
#
# 依赖：macOS 或 Linux + Theos（含 iOS SDK、ldid、make）
#   bash -c "$(curl -fsSL https://raw.githubusercontent.com/theos/theos/master/bin/install-theos)"
#
set -euo pipefail
cd "$(dirname "$0")"

# ---------- 1. 可选：重写过滤 plist ----------
if [ "$#" -gt 0 ]; then
    command -v python3 >/dev/null || { echo "需要 python3 来生成 plist"; exit 1; }
    python3 - "$@" <<'PY'
import plistlib, sys
path = "FakeGPS.plist"
with open(path, "rb") as f:
    data = plistlib.load(f)
data.setdefault("Filter", {})["Bundles"] = sys.argv[1:]
with open(path, "wb") as f:
    plistlib.dump(data, f)
print("过滤目标:", ", ".join(sys.argv[1:]))
PY
fi

# ---------- 2. 检查 Theos ----------
export THEOS="${THEOS:-$HOME/theos}"
if [ ! -d "$THEOS/makefiles" ]; then
    echo "找不到 Theos：$THEOS"
    echo "安装：bash -c \"\$(curl -fsSL https://raw.githubusercontent.com/theos/theos/master/bin/install-theos)\""
    exit 1
fi

# ---------- 3. 构建 ----------
make clean >/dev/null 2>&1 || true
make package FINALPACKAGE=1

echo
echo "======== 产物 ========"
ls -lh packages/*.deb 2>/dev/null || true
find .theos/obj -maxdepth 4 -name 'FakeGPS.dylib' -print 2>/dev/null || true
